import app from './app';

app.listen(process.env.PORT || 3333, () => console.log("App listening on port 3333!"));